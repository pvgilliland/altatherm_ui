import customtkinter as ctk
from typing import TYPE_CHECKING, Dict, Any
import logging

from hmi_consts import HMIColors, HMISizePos
from ui_bits import COLOR_FG, COLOR_BLUE

if TYPE_CHECKING:
    from MultiPageController import MultiPageController

logger = logging.getLogger("DiagnosticsPage2")


class DiagnosticsPage2(ctk.CTkFrame):
    def __init__(
        self, controller: "MultiPageController", shared_data: Dict[str, Any], **kwargs
    ):
        super().__init__(controller, fg_color=COLOR_FG, **kwargs)
        self.controller = controller
        self.shared_data = shared_data

        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=0)
        self.grid_columnconfigure(0, weight=1)

        btn_font = ctk.CTkFont(family="Arial", size=18, weight="bold")

        # ----- Header -----
        header = ctk.CTkFrame(self, fg_color=COLOR_FG)
        header.grid(row=0, column=0, sticky="nsew", padx=10, pady=(10, 0))

        ctk.CTkLabel(
            header,
            text="Diagnostics 2",
            text_color=COLOR_BLUE,
            font=("Arial", 20, "bold"),
        ).pack(pady=(4, 8))

        ctk.CTkFrame(header, height=2, fg_color=COLOR_BLUE).pack(
            fill="x", padx=2, pady=(0, 6)
        )

        # ----- Body (blank) -----
        body = ctk.CTkFrame(
            self,
            fg_color=COLOR_FG,
            corner_radius=8,
            border_width=2,
            border_color=COLOR_BLUE,
        )
        body.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)

        # ----- Footer -----
        footer = ctk.CTkFrame(self, fg_color=COLOR_FG)
        footer.grid(row=2, column=0, sticky="nsew", padx=10, pady=(0, 10))

        back_btn = ctk.CTkButton(
            footer,
            text="← Back",
            command=self.on_back,
            font=btn_font,
            fg_color=HMIColors.color_fg,
            text_color=HMIColors.color_blue,
            corner_radius=20,
            border_width=2,
            border_color=HMIColors.color_blue,
            hover_color=HMIColors.color_numbers,
            width=HMISizePos.sx(110),
            height=HMISizePos.BTN_HEIGHT,
        )
        back_btn.pack(side="left", padx=10, pady=6)

        refresh_btn = ctk.CTkButton(
            footer,
            text="Refresh",
            command=self.on_refresh,
            font=btn_font,
            fg_color=HMIColors.color_fg,
            text_color=HMIColors.color_blue,
            corner_radius=20,
            border_width=2,
            border_color=HMIColors.color_blue,
            hover_color=HMIColors.color_numbers,
            width=HMISizePos.sx(110),
            height=HMISizePos.BTN_HEIGHT,
        )
        refresh_btn.pack(side="right", padx=10, pady=6)

    def on_show(self):
        print("[DiagnosticsPage2] on_show")

    def on_hide(self):
        print("[DiagnosticsPage2] on_hide")

    def on_back(self):
        if hasattr(self.controller, "show_DiagnosticsPage"):
            self.controller.show_DiagnosticsPage()
        else:
            print("[DiagnosticsPage2] Controller missing show_DiagnosticsPage()")

    def on_refresh(self):
        print("[DiagnosticsPage2] Refreshed")


# ---- Standalone test harness ----
if __name__ == "__main__":

    class DummyController(ctk.CTk):
        def __init__(self):
            super().__init__()
            self.title("DiagnosticsPage2 Test")
            self.geometry("1024x600")
            self.shared_data = {}

        def show_DiagnosticsPage(self):
            print("[DummyController] Returning to DiagnosticsPage")

    app = DummyController()
    page = DiagnosticsPage2(controller=app, shared_data=app.shared_data)
    page.pack(fill="both", expand=True)
    app.mainloop()
