from __future__ import annotations  # if you're on Python 3.8/3.9
from typing import Optional, TYPE_CHECKING

from TimePowerPage import TimePowerPage  # only for typing; no runtime import

import time
from typing import Optional
import customtkinter as ctk
from PIL import Image

from DoorSafety import DoorSafety
from hmi_consts import ASSETS_DIR, HMIColors
from hmi_consts import SETTINGS_DIR
import os, json

from CircularProgress_admin import CircularProgress_admin
from SerialService import SerialService
from MessageBoxPage import showerror
from Settings import Settings
import oven_state
import logging

logger = logging.getLogger(__name__)

PERIODIC_THERMISTOR = True
PERIODIC_INTRERVAL_MS = 1000
WDT_TIMEOUT_MS = 30000
WDT_STARTUP_DELAY_MS = 2000


class CircularProgressPage_admin(ctk.CTkFrame):
    """
    A MultiPageController-friendly page that shows a full-screen circular
    countdown with a single STOP button.
    """

    def __init__(self, controller, shared_data=None, **kwargs):
        super().__init__(controller, fg_color=HMIColors.color_fg, **kwargs)
        self.controller = controller
        self.shared_data = shared_data

        self._time_power_page: Optional["TimePowerPage"] = None

        # Internal state
        self.total_time = 0.0
        self.remaining_time = 0.0
        self._start_epoch = None
        self._running = False
        self._on_stop = None

        # Cached alarm level (loaded on_show)
        self._alarm_level: int = 1500
        self._alarm_hysteresis: int = 400
        self._inAlarmState: bool | None = False
        self._prevAlarmState: bool | None = None

        self._isManualCookMode: bool = False
        self._powerLevel: int | None = None
        self._over_temp_power: float = 0.75
        self._enable_array_temp_control: bool = False
        self.enable_cook_algorithm: bool = False

        # Cookpack temperature control state
        self.tset: float = 0.0
        self.thys: float = 0.0
        self.top_zones_correction_factor: float = 100.0
        self.bottom_zones_correction_factor: float = 100.0
        self.tc: float = 0.0

        self._ir_temps: dict[int, float] = {}
        self._cookpack_control_active: bool = False
        self._cookpack_tc_remaining: float = 0.0
        self._cookpack_last_tick_time: float | None = None
        self._cookpack_finished: bool = False

        # Actual running percentages currently being commanded
        self._cookpack_top_running_pct: float = 100.0
        self._cookpack_bottom_running_pct: float = 100.0

        # --- NEW: completely independent 1-second periodic timer ------------
        self._periodic_callback = None
        self._periodic_after_id = None
        if PERIODIC_THERMISTOR:
            self._start_periodic_timer()
        self.bind("<Destroy>", lambda e: self._cancel_periodic_timer())

        # Layout for 800x480
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)
        self.grid_columnconfigure(0, weight=1)

        self.progress = CircularProgress_admin(self, size=360, thickness=22)
        self.progress.grid(row=0, column=0, pady=(24, 0))

        self.stop_button = ctk.CTkButton(
            self,
            text="STOP",
            width=220,
            height=56,
            corner_radius=18,
            font=ctk.CTkFont(size=24, weight="bold"),
            command=self.stop,
        )
        self.stop_button.grid(row=1, column=0, pady=(18, 24))

        self.progress.update_progress(0, 1)

        # --- Over-temp icon in upper right ---------------------------------
        try:
            overtemp_size = (96, 96)
            img = Image.open(f"{ASSETS_DIR}/over_temp.png")
            img = img.resize(overtemp_size, Image.Resampling.LANCZOS)
            self._overtemp_icon = ctk.CTkImage(
                light_image=img, dark_image=img, size=overtemp_size
            )
            self._overtemp_lbl = ctk.CTkLabel(self, image=self._overtemp_icon, text="")
        except Exception as e:
            print(f"Failed to load over_temp.png: {e}")
            self._overtemp_lbl = None

        # --- Power/Scale label ---------------------------------------------
        self._power_var = ctk.StringVar(value="Power: N/A")
        self._power_lbl = ctk.CTkLabel(
            self,
            textvariable=self._power_var,
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color=HMIColors.TEXT_COLOR,
        )
        self._power_lbl.place(relx=1.0, rely=0.0, anchor="ne", x=-25, y=130)

        # --- lower-right status label for last serial line ------------------
        self._last_line_var = ctk.StringVar(value="")
        self._last_line_lbl = ctk.CTkLabel(
            self,
            textvariable=self._last_line_var,
            font=ctk.CTkFont(size=24),
            text_color=HMIColors.TEXT_COLOR,
        )
        self._last_line_lbl.place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-22)

        # --- lower-right T1..T4 labels -------------------------------------
        self._t1_var = ctk.StringVar(value="T1 = N/A        ")
        self._t1_lbl = ctk.CTkLabel(
            self,
            textvariable=self._t1_var,
            font=ctk.CTkFont(size=24),
            text_color=HMIColors.TEXT_COLOR,
        )

        _yStart = -180
        _LINE_HEIGHT = 40

        self._algo_status_var = ctk.StringVar(value="")
        self._algo_status_lbl = ctk.CTkLabel(
            self,
            textvariable=self._algo_status_var,
            font=ctk.CTkFont(size=20),
            text_color=HMIColors.TEXT_COLOR,
        )
        self._algo_status_lbl.place(
            relx=1.0, rely=1.0, anchor="se", x=-10, y=_yStart - _LINE_HEIGHT
        )

        self._t1_lbl.place(
            relx=1.0, rely=1.0, anchor="se", x=-10, y=_yStart + 0 * _LINE_HEIGHT
        )

        self._t2_var = ctk.StringVar(value="T2 = N/A        ")
        self._t2_lbl = ctk.CTkLabel(
            self,
            textvariable=self._t2_var,
            font=ctk.CTkFont(size=24),
            text_color=HMIColors.TEXT_COLOR,
        )
        self._t2_lbl.place(
            relx=1.0, rely=1.0, anchor="se", x=-10, y=_yStart + 1 * _LINE_HEIGHT
        )

        self._t3_var = ctk.StringVar(value="T3 = N/A        ")
        self._t3_lbl = ctk.CTkLabel(
            self,
            textvariable=self._t3_var,
            font=ctk.CTkFont(size=24),
            text_color=HMIColors.TEXT_COLOR,
        )
        self._t3_lbl.place(
            relx=1.0, rely=1.0, anchor="se", x=-10, y=_yStart + 2 * _LINE_HEIGHT
        )

        self._t4_var = ctk.StringVar(value="T4 = N/A        ")
        self._t4_lbl = ctk.CTkLabel(
            self,
            textvariable=self._t4_var,
            font=ctk.CTkFont(size=24),
            text_color=HMIColors.TEXT_COLOR,
        )
        self._t4_lbl.place(
            relx=1.0, rely=1.0, anchor="se", x=-10, y=_yStart + 3 * _LINE_HEIGHT
        )

        # --- lower-left cookpack status labels ------------------------------
        self._cookpack_tc_var = ctk.StringVar(value="")
        self._cookpack_top_var = ctk.StringVar(value="")
        self._cookpack_bottom_var = ctk.StringVar(value="")

        self._cookpack_tc_lbl = ctk.CTkLabel(
            self,
            textvariable=self._cookpack_tc_var,
            font=ctk.CTkFont(size=22),
            text_color=HMIColors.TEXT_COLOR,
        )
        self._cookpack_top_lbl = ctk.CTkLabel(
            self,
            textvariable=self._cookpack_top_var,
            font=ctk.CTkFont(size=22),
            text_color=HMIColors.TEXT_COLOR,
        )
        self._cookpack_bottom_lbl = ctk.CTkLabel(
            self,
            textvariable=self._cookpack_bottom_var,
            font=ctk.CTkFont(size=22),
            text_color=HMIColors.TEXT_COLOR,
        )

        _left_x = 10
        _bottom_y = -22
        _left_line_height = 34

        self._cookpack_tc_lbl.place(
            relx=0.0,
            rely=1.0,
            anchor="sw",
            x=_left_x,
            y=_bottom_y - 2 * _left_line_height,
        )
        self._cookpack_top_lbl.place(
            relx=0.0,
            rely=1.0,
            anchor="sw",
            x=_left_x,
            y=_bottom_y - 1 * _left_line_height,
        )
        self._cookpack_bottom_lbl.place(
            relx=0.0,
            rely=1.0,
            anchor="sw",
            x=_left_x,
            y=_bottom_y - 0 * _left_line_height,
        )

        self.serial: Optional["SerialService"] = getattr(
            self.controller, "serial", None
        )
        if self.serial:
            self.serial.add_listener(self._on_serial_line)
            print("have serial")

        self.set_periodic_callback(self.on_read_controller_thermistors)

        self._wdt_after_id = None
        self._wdt_timeout_ms = WDT_TIMEOUT_MS
        if PERIODIC_THERMISTOR:
            self.after(WDT_STARTUP_DELAY_MS, self._kick_watchdog)

    # ---- Public API -----------------------------------------------------

    def on_show(
        self,
        isManualCookMode: bool | None = None,
        time_power_page: TimePowerPage | None = None,
        powerLevel: int | None = None,
    ):
        self._isManualCookMode = bool(isManualCookMode)
        self._time_power_page = time_power_page
        self._powerLevel = powerLevel

        self._prevAlarmState = None
        self._inAlarmState = None

        self._alarm_level, self._alarm_hysteresis = (
            self._load_alarm_levels_from_settings()
        )
        self._over_temp_power = self._load_over_temp_power_from_settings(default=0.75)
        self._enable_array_temp_control = (
            self._load_enable_array_temp_control_from_settings(default=False)
        )

        s = Settings.Instance()
        s.load()
        self.tset = float(s.tset)
        self.thys = float(s.thys)
        self.top_zones_correction_factor = float(s.top_zones_correction_factor)
        self.bottom_zones_correction_factor = float(s.bottom_zones_correction_factor)
        self.tc = float(s.tc)
        self.enable_cook_algorithm = bool(s.enable_cook_algorithm)

        self._cookpack_reset_state()

        self._algo_status_var.set(
            f"Array Temp Ctrl: {'ON' if self._enable_array_temp_control else 'OFF'}, "
            f"Cookpack Temp Ctrl: {'ON' if self.enable_cook_algorithm else 'OFF'}"
        )

        self.set_overtemp_visible(False)
        self._update_cookpack_display()

        if self._isManualCookMode:
            self.set_power_display(int(self._powerLevel) if self._powerLevel else None)
        else:
            self.set_power_display(100)

    def set_power_display(self, value: int | None):
        try:
            if value is None:
                self._power_var.set(
                    "Power: N/A" if self._isManualCookMode else "Scale: N/A"
                )
            else:
                if self._isManualCookMode:
                    self._power_var.set(f"{value}% Power")
                else:
                    self._power_var.set(f"Scale: {value}%")
        except Exception:
            self._power_var.set(
                "Power: N/A" if self._isManualCookMode else "Scale: N/A"
            )

    # ---------------------- Helper: settings -------------------------------

    def _load_alarm_levels_from_settings(
        self, defaultAlarmLevel: int = 1500, defaultHysteresis: int = 400
    ) -> tuple[int, int]:
        path = os.path.join(SETTINGS_DIR, "settings.alt")
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    data = json.load(f)
                    return int(data.get("alarm_level", defaultAlarmLevel)), int(
                        data.get("alarm_hysteresis", defaultHysteresis)
                    )
        except Exception:
            pass
        return defaultAlarmLevel, defaultHysteresis

    def _load_over_temp_power_from_settings(self, default: float = 0.75) -> float:
        path = os.path.join(SETTINGS_DIR, "settings.alt")
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    data = json.load(f)
                    return float(data.get("over_temp_power", default))
        except Exception:
            pass
        return default

    def _load_enable_array_temp_control_from_settings(
        self, default: bool = False
    ) -> bool:
        path = os.path.join(SETTINGS_DIR, "settings.alt")
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    data = json.load(f)
                    return bool(data.get("enable_array_temp_control", default))
        except Exception:
            pass
        return default

    # ---------------------- Helpers: UI / stop -----------------------------

    def set_overtemp_visible(self, show: bool):
        if self._overtemp_lbl:
            if show:
                self._overtemp_lbl.place(relx=1.0, rely=0.0, anchor="ne", x=-25, y=25)
            else:
                self._overtemp_lbl.place_forget()

    def _update_cookpack_display(self) -> None:
        if self.enable_cook_algorithm:
            self._cookpack_tc_var.set(f"tC: {self._cookpack_tc_remaining:.1f}s")
            self._cookpack_top_var.set(
                f"Top Running: {self._cookpack_top_running_pct:.0f}%"
            )
            self._cookpack_bottom_var.set(
                f"Bottom Running: {self._cookpack_bottom_running_pct:.0f}%"
            )
        else:
            self._cookpack_tc_var.set("")
            self._cookpack_top_var.set("")
            self._cookpack_bottom_var.set("")

    def start(self, start_seconds: float, on_stop=None):
        self.total_time = max(0.0, float(start_seconds))
        self.remaining_time = self.total_time
        self._on_stop = on_stop

        self._running = True
        self._start_epoch = time.time()
        self._tick()

    def stop(self):
        self._running = False
        if self.remaining_time <= 0.001:
            self.progress.update_progress(0, self.total_time)

        self._stop_manager()

        if self._on_stop:
            cb, self._on_stop = self._on_stop, None
            try:
                cb()
            except Exception as e:
                print(f"[CircularProgressPage] on_stop callback failed: {e}")
        else:
            try:
                self.controller.serial_all_zones_off()
            except Exception:
                pass

        try:
            self.controller.show_HomePage()
        except Exception as e:
            print(f"[CircularProgressPage] Failed to navigate HomePage: {e}")

    def _stop_manager(self):
        try:
            mgr = (self.shared_data or {}).get("sequence_manager")
            if mgr:
                if hasattr(mgr, "stop_all"):
                    mgr.stop_all()
                elif hasattr(mgr, "request_stop"):
                    mgr.request_stop()
        except Exception as e:
            print(f"[CircularProgressPage] stop manager failed: {e}")

    def _tick(self):
        if not self._running:
            return

        elapsed = time.time() - self._start_epoch
        self.remaining_time = max(0.0, self.total_time - elapsed)

        self.progress.update_progress(self.remaining_time, self.total_time)

        if self.remaining_time > 0.0:
            self.after(50, self._tick)
        else:
            self._running = False
            self.progress.update_progress(0, self.total_time)
            self._stop_manager()

            if self._on_stop:
                cb, self._on_stop = self._on_stop, None
                try:
                    cb()
                except Exception as e:
                    print(f"[CircularProgressPage] on_stop callback failed: {e}")

            try:
                self.controller.show_FoodReadyPage(
                    auto_return_to=TimePowerPage, after_ms=10000
                )
            except Exception:
                pass

    # ===================== Periodic controller poll =========================

    def set_periodic_callback(self, callback):
        self._periodic_callback = callback

    def _start_periodic_timer(self):
        self._periodic_tick()

    def _periodic_tick(self):
        if self._periodic_callback is not None:
            try:
                self._periodic_callback()
            except Exception as e:
                print(f"[CircularProgressPage] periodic callback failed: {e}")
        try:
            self._periodic_after_id = self.after(
                PERIODIC_INTRERVAL_MS, self._periodic_tick
            )
        except Exception:
            self._periodic_after_id = None

    def _cancel_periodic_timer(self):
        if self._periodic_after_id is not None:
            try:
                self.after_cancel(self._periodic_after_id)
            except Exception:
                pass
            self._periodic_after_id = None

    from StopWatch import Stopwatch

    _sw = Stopwatch()
    _sw1 = Stopwatch()

    def on_read_controller_thermistors(self):
        try:
            self._sw.stop()
            if self._sw.elapsed_ms() > (PERIODIC_INTRERVAL_MS * 1.25):
                s = f"[on_read_controller_thermistors] = {self._sw.elapsed_ms():.3f}"
                logger.info(s)
                print(s)
            self._sw.reset()
            self._sw.start()

            self.controller.serial_get_thermistor()
            for sendorId in range(1, 5):
                self.controller.serial_get_IR_temp(sendorId)
        except Exception:
            pass

    # ===================== Watchdog Timer ===================================

    def _kick_watchdog(self):
        if self._wdt_after_id is not None:
            try:
                self.after_cancel(self._wdt_after_id)
            except Exception:
                pass
        self._wdt_after_id = self.after(self._wdt_timeout_ms, self._wdt_expired)

    def _wdt_expired(self):
        print("[CircularProgressPage] Watchdog expired: no serial data")
        try:
            logger.info("Lost communication with the controller!")
            DoorSafety.Instance().set_wdt_timed_out(True)

            self.stop()
            if self.controller.is_admin:
                showerror(
                    self.controller, "Error", "Lost communication with the controller!"
                )
        except Exception as e:
            print(f"[CircularProgressPage] Failed to show error: {e}")

    # ===================== Existing array-temp helpers =======================

    def _set_power_if_running(self, pct: float) -> None:
        with oven_state.lock:
            if (
                oven_state.is_running
                and getattr(self, "_time_power_page", None) is not None
            ):
                self._time_power_page.set_power_to_percent_of_set_value(pct)

    def _set_program_scale(self, scale: float) -> None:
        try:
            mgr = (self.shared_data or {}).get("sequence_manager")
            if mgr and hasattr(mgr, "set_power_scale"):
                mgr.set_power_scale(max(0.0, min(1.0, float(scale))))
        except Exception as e:
            print(f"[CircularProgressPage] set_program_scale failed: {e}")

    def _set_program_scale_for_arrays(
        self, scale: float, arrays: list[int] | tuple[int, ...]
    ) -> None:
        """
        Program-run throttle for only selected arrays/zones.

        scale:
            0.0 .. 1.0

        arrays:
            iterable of zone numbers, e.g. [1,2,3,4] or [5,6,7,8]
        """

        try:
            mgr = (self.shared_data or {}).get("sequence_manager")
            if mgr is None:
                return

            scale = max(0.0, min(1.0, float(scale)))
            arrays = [int(a) for a in arrays]

            if hasattr(mgr, "set_zone_scale"):
                for zone in arrays:
                    mgr.set_zone_scale(zone, scale)
                return

            if hasattr(mgr, "set_array_scale"):
                for zone in arrays:
                    mgr.set_array_scale(zone, scale)
                return

            if hasattr(mgr, "set_selected_zone_scale"):
                mgr.set_selected_zone_scale(arrays, scale)
                return

            if hasattr(mgr, "set_selected_array_scale"):
                mgr.set_selected_array_scale(arrays, scale)
                return

            logger.info(
                "[CircularProgressPage] set_program_scale_for_arrays failed: "
                "no supported per-array scaling API found"
            )

        except Exception as e:
            print(f"[CircularProgressPage] set_program_scale_for_arrays failed: {e}")

    # ===================== Cookpack temp control helpers ====================

    def _cookpack_reset_state(self) -> None:
        self._ir_temps = {}
        self._cookpack_control_active = False
        self._cookpack_tc_remaining = float(self.tc)
        self._cookpack_last_tick_time = None
        self._cookpack_finished = False
        self._cookpack_top_running_pct = 100.0
        self._cookpack_bottom_running_pct = 100.0
        self._update_cookpack_display()

    def _parse_temp_value(self, line: str) -> float | None:
        """
        Returns the first numeric value from strings like:
        T1 = 54.3
        T1=54.3
        T1 54.3
        50.0,0.0
        T1=50.0,0.0
        """
        try:
            s = line.strip()

            if "=" in s:
                s = s.split("=", 1)[1].strip()
            elif s.startswith("T") and len(s) > 2 and s[1].isdigit():
                s = s[2:].strip()

            first_value = s.split(",", 1)[0].strip()
            return float(first_value)

        except Exception:
            return None

    def _get_t0(self) -> float | None:
        t1 = self._ir_temps.get(1)
        t2 = self._ir_temps.get(2)
        if t1 is None or t2 is None:
            return None
        return (t1 + t2) / 2.0

    def _finish_cookpack_cycle(self) -> None:
        if self._cookpack_finished:
            return
        self._cookpack_finished = True
        self._cookpack_tc_remaining = 0.0

        # Restore all zones to 100%
        self._set_program_scale_for_arrays(1.0, [1, 2, 3, 4])
        self._set_program_scale_for_arrays(1.0, [5, 6, 7, 8])
        self._cookpack_top_running_pct = 100.0
        self._cookpack_bottom_running_pct = 100.0
        self._update_cookpack_display()

        logger.info("[Cookpack] tC expired, ending cook cycle")

        self._running = False
        self.progress.update_progress(0, self.total_time)
        self._stop_manager()

        try:
            self.controller.show_FoodReadyPage(
                auto_return_to=TimePowerPage, after_ms=10000
            )
        except Exception:
            pass

    def _evaluate_cookpack_temp_control(self) -> None:

        if not self.enable_cook_algorithm:
            return
        if not oven_state.get_running():
            return
        if self._cookpack_finished:
            return

        t0 = self._get_t0()
        print(
            f"_evaluate_cookpack_temp_control: t0={t0}, tset={self.tset}, thys={self.thys}"
        )

        if t0 is None:
            return

        now = time.time()

        # Enter/continue control region
        if t0 > self.tset:
            self._set_program_scale_for_arrays(
                self.bottom_zones_correction_factor / 100.0, [1, 2, 3, 4]
            )
            self._set_program_scale_for_arrays(
                self.top_zones_correction_factor / 100.0, [5, 6, 7, 8]
            )
            self._cookpack_top_running_pct = float(self.top_zones_correction_factor)
            self._cookpack_bottom_running_pct = float(
                self.bottom_zones_correction_factor
            )
            self._update_cookpack_display()

            if not self._cookpack_control_active:
                self._cookpack_control_active = True
                self._cookpack_last_tick_time = now
                self._update_cookpack_display()
                logger.info(
                    f"[Cookpack] Entered control band, T0={t0:.2f}, tC={self._cookpack_tc_remaining:.1f}s"
                )
                return

            if self._cookpack_last_tick_time is None:
                self._cookpack_last_tick_time = now
                self._update_cookpack_display()
                return

            dt = now - self._cookpack_last_tick_time
            self._cookpack_last_tick_time = now
            self._cookpack_tc_remaining = max(0.0, self._cookpack_tc_remaining - dt)
            self._update_cookpack_display()

            logger.info(
                f"[Cookpack] T0={t0:.2f} > TSET={self.tset:.2f}, "
                f"tC remaining={self._cookpack_tc_remaining:.1f}s"
            )

            if self._cookpack_tc_remaining <= 0.0:
                self._finish_cookpack_cycle()
            return

        # Exit control region only when below lower hysteresis threshold
        if t0 < (self.tset - self.thys):
            if self._cookpack_control_active:
                logger.info(
                    f"[Cookpack] Left control band, T0={t0:.2f} < (TSET-THYS)={(self.tset - self.thys):.2f}"
                )

            self._cookpack_control_active = False
            self._cookpack_last_tick_time = None

            self._set_program_scale_for_arrays(1.0, [1, 2, 3, 4])
            self._set_program_scale_for_arrays(1.0, [5, 6, 7, 8])
            self._cookpack_top_running_pct = 100.0
            self._cookpack_bottom_running_pct = 100.0
            self._update_cookpack_display()

    # ===================== Serial handling ==================================

    def _on_serial_line(self, line: str) -> None:
        try:
            if line.startswith("T0"):
                return

            if line.startswith("D=") and (len(line) == 3):
                doorOpen: bool = line[2:3] == "1"
                print(f"Door Open = {doorOpen}")
                DoorSafety.Instance().set_open(doorOpen)

            if line.startswith("L=") and (len(line) == 3):
                lockError: bool = line[2:3] == "3"
                DoorSafety.Instance().set_door_lock_error(lockError)

            if line.startswith("R="):
                if PERIODIC_THERMISTOR:
                    self._kick_watchdog()

                self._sw1.stop()
                if self._sw1.elapsed_ms() > (PERIODIC_INTRERVAL_MS * 1.25):
                    s = f"[_on_serial_line] = {self._sw1.elapsed_ms():.3f}"
                    logger.info(s)
                    print(s)
                self._sw1.reset()
                self._sw1.start()

                self._last_line_var.set(line)

                if not self.controller.is_admin:
                    return

                try:
                    if oven_state.get_running():
                        r1_str, r2_str = line[2:].split(",", 1)
                        r1, r2 = int(r1_str), int(r2_str)

                        if not self._enable_array_temp_control:
                            if self._inAlarmState:
                                self.set_overtemp_visible(False)

                                if self._isManualCookMode:
                                    self._set_power_if_running(1.0)
                                    if self._powerLevel is not None:
                                        self.set_power_display(int(self._powerLevel))
                                    else:
                                        self.set_power_display(100)
                                else:
                                    self._set_program_scale(1.0)
                                    self.set_power_display(100)

                            self._inAlarmState = False
                            return

                        L = self._alarm_level
                        H = self._alarm_hysteresis

                        if self._inAlarmState is None:
                            if self._isManualCookMode:
                                self.set_power_display(
                                    int(self._powerLevel) if self._powerLevel else None
                                )
                            else:
                                self.set_power_display(100)

                        prev = bool(self._inAlarmState)

                        if prev:
                            in_alarm = not (r1 > L + H and r2 > L + H)
                        else:
                            in_alarm = (r1 < L) or (r2 < L)

                        if in_alarm != prev:
                            self.set_overtemp_visible(in_alarm)

                            if in_alarm:
                                throttle: float = self._over_temp_power
                                if self._isManualCookMode:
                                    self._set_power_if_running(throttle)
                                    if self._powerLevel is not None:
                                        self.set_power_display(
                                            int(throttle * self._powerLevel)
                                        )
                                    else:
                                        self.set_power_display(int(throttle * 100))
                                else:
                                    self._set_program_scale(throttle)
                                    self.set_power_display(int(throttle * 100))
                            else:
                                if self._isManualCookMode:
                                    self._set_power_if_running(1.0)
                                    if self._powerLevel is not None:
                                        self.set_power_display(int(self._powerLevel))
                                    else:
                                        self.set_power_display(100)
                                else:
                                    self._set_program_scale(1.0)
                                    self.set_power_display(100)

                        self._inAlarmState = in_alarm

                except ValueError:
                    pass

            if line.startswith("T1"):
                self._t1_var.set(line)
                temp = self._parse_temp_value(line)
                if temp is not None:
                    self._ir_temps[1] = temp
                    self._evaluate_cookpack_temp_control()

            if line.startswith("T2"):
                self._t2_var.set(line)
                temp = self._parse_temp_value(line)
                if temp is not None:
                    self._ir_temps[2] = temp
                    self._evaluate_cookpack_temp_control()

            if line.startswith("T3"):
                self._t3_var.set(line)
                temp = self._parse_temp_value(line)
                if temp is not None:
                    self._ir_temps[3] = temp

            if line.startswith("T4"):
                self._t4_var.set(line)
                temp = self._parse_temp_value(line)
                if temp is not None:
                    self._ir_temps[4] = temp

            if oven_state.get_running() and line.startswith(("T1", "T2", "T3", "T4")):
                logger.info(line)

        except Exception:
            pass


# --- Example usage ------------------------------------------------------
if __name__ == "__main__":
    ctk.set_appearance_mode("light")
    app = ctk.CTk()
    app.geometry("800x480")

    page = CircularProgressPage_admin(app)
    page.pack(fill="both", expand=True)
    page.start(10, on_stop=lambda: print("Timer stopped"))

    app.mainloop()
