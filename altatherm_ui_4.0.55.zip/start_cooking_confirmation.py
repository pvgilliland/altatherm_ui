import json
import os
from typing import List
from DoorSafety import DoorSafety
from hotspots import Hotspot
from hmi_consts import ASSETS_DIR, PROGRAMS_DIR
from SelectProgramPage import (
    load_program_into_sequence_collection,
)


class StartCookingConfirmation:
    """
    Page model:
      - uses homepage.png
      - defines three hotspots and their callbacks
    """

    IMAGE_NAME = "04ConfirmationPage.png"

    def __init__(self, controller):
        self.controller = controller
        self.meal_index: int | None = None

        # dictionary
        self.meal_images = {
            0: ("food.png", "Item 1"),
            1: ("food.png", "Item 2"),
            2: ("food.png", "Item 3"),
            3: ("food.png", "Item 4"),
            4: ("food.png", "Item 5"),
            5: ("Reheat.png", "Reheat"),
            6: ("food.png", "Item 7"),
            7: ("food.png", "Item 8"),
            8: ("food.png", "Item 9"),
            9: ("food.png", "Item 10"),
            10: ("food.png", "Item 11"),
            11: ("food.png", "Item 12"),
            9999: ("food.png", "Item 9999"),
        }

        here = os.path.dirname(__file__) if "__file__" in globals() else os.getcwd()
        assets_dir = os.path.join(here, "assets")
        os.makedirs(assets_dir, exist_ok=True)

        self.image_path = os.path.join(assets_dir, self.IMAGE_NAME)

        self.hotspots: List[Hotspot] = [
            Hotspot(
                "back",
                (84, 642, 154, 707),
                self.on_back_clicked,
            ),
            Hotspot(
                "start",
                (490, 641, 785, 716),
                self.on_start_clicked,
            ),
            Hotspot(
                "home",
                (1138, 43, 1205, 98),
                self.on_home_clicked,
            ),
            Hotspot(
                "question",
                (1115, 634, 1212, 722),
                self.on_question_clicked,
            ),
        ]

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def on_question_clicked(self):
        print(f"on_question_clicked {self.meal_index}")

        if not self.controller:
            return

        if self.meal_index == 5:
            self.controller.shared_data["show_reheat_time_attention"] = True

            view = getattr(self.controller, "view", None)
            if view and hasattr(view, "show_reheat_time_attention"):
                view.show_reheat_time_attention()

            return

        self.controller.shared_data["show_reheat_time_attention"] = False
        self.controller.show_PrepareForCookingPage1(
            from_info=False,
            meal_index=self.meal_index,
        )

    def on_home_clicked(self):
        print("on_home_clicked")
        if not self.controller:
            return

        self.controller.shared_data["show_reheat_time_attention"] = False

        view = getattr(self.controller, "view", None)
        if view and hasattr(view, "hide_reheat_time_attention"):
            view.hide_reheat_time_attention()

        self.controller.show_HomePage()

    def on_back_clicked(self):
        print("on_back_clicked")
        if self.controller:
            self.controller.shared_data["show_reheat_time_attention"] = False

            view = getattr(self.controller, "view", None)
            if view and hasattr(view, "hide_reheat_time_attention"):
                view.hide_reheat_time_attention()

            self.controller.show_PrepareForCookingPage2(
                from_info=False,
                meal_index=self.meal_index,
            )

    def on_start_clicked(self):
        print("StartCookingConfirmation: Start clicked")

        # ------------------------------------------------------------
        # BLOCK START IF DOOR IS OPEN
        # ------------------------------------------------------------
        if DoorSafety.Instance().is_open():
            print("[StartCookingConfirmation] Door is open → Start disabled")
            return

        if not self.controller:
            return

        # ------------------------------------------------------------
        # BLOCK START IF EFFECTIVE COOK TIME IS ZERO
        # ------------------------------------------------------------
        # Reheat mode (meal_index == 5) → use the reheat time control
        if self.meal_index == 5:
            view = getattr(self.controller, "view", None)
            reheat_secs = 0

            if view and hasattr(view, "get_reheat_seconds"):
                try:
                    reheat_secs = int(view.get_reheat_seconds() or 0)
                except (TypeError, ValueError):
                    reheat_secs = 0

            reheat_secs = max(0, reheat_secs)

            if reheat_secs == 0:
                print(
                    "[StartCookingConfirmation] Reheat time = 0 → ignoring Start click"
                )
                return  # Do nothing if reheat time is zero

            # Valid reheat time → store in shared_data for CookingPage
            print(f"[StartCookingConfirmation] reheat_seconds = {reheat_secs}")
            self.controller.shared_data["reheat_seconds"] = reheat_secs
            self.controller.shared_data["show_reheat_time_attention"] = False

        else:
            # Normal meal: look up the program's total_time and block if 0
            meal_index_offset = 31
            # check if we got here because of an rfid read
            if self.meal_index == 9999:
                meal_index_offset = 0

            program_number = self.meal_index + meal_index_offset
            path = str(PROGRAMS_DIR / f"program{program_number}.alt")

            try:
                with open(path, "r") as f:
                    data = json.load(f)
                total_time = data.get("total_time", "0:00") or "0:00"
            except Exception as e:
                print(f"[StartCookingConfirmation] Failed to read {path}: {e}")
                total_time = "0:00"

            # Convert "MM:SS" → total seconds
            try:
                minutes, seconds = map(int, str(total_time).split(":"))
                total_seconds = minutes * 60 + seconds
            except Exception:
                total_seconds = 0

            if total_seconds == 0:
                print(
                    "[StartCookingConfirmation] total_time = 0 → ignoring Start click"
                )
                return  # Do nothing if program time is zero

        # ------------------------------------------------------------
        # If we reach here, cook is allowed to start
        # ------------------------------------------------------------

        # Clear any prior Door Lock error when cooking starts
        try:
            view = getattr(self.controller, "view", None)
            if view and hasattr(view, "_on_door_lock_error"):
                view._on_door_lock_error(False)
            if view and hasattr(view, "hide_reheat_time_attention"):
                view.hide_reheat_time_attention()
        except Exception:
            pass

        self.controller.show_CookingPage(meal_index=self.meal_index)

    # ------------------------------------------------------------------
    # Methods
    # ------------------------------------------------------------------
    def on_show(self, meal_index: int):
        if meal_index not in self.meal_images:
            raise ValueError(f"Unsupported meal_index: {meal_index}")

        self.meal_index = meal_index

        filename, name = self.meal_images[meal_index]
        if not filename:
            self.controller.view.set_overlay_image(None)
            return

        image_path = os.path.join(ASSETS_DIR, filename)
        program_number = 9999 if meal_index == 9999 else meal_index + 31

        print(
            "[StartCookingConfirmation] "
            f"meal_index={meal_index}, program_number={program_number}"
        )

        load_program_into_sequence_collection(program_number)

        path = str(PROGRAMS_DIR / f"program{program_number}.alt")
        with open(path, "r") as f:
            data = json.load(f)
        total_time = data.get("total_time", "0:00")

        self.controller.view.set_overlay_image(
            image_path, name, total_time, size=(270, 200)
        )

        if meal_index == 5:
            print("Showing TimeAdjustControl for Reheat")

            self.controller.view.show_reheat_time_control(
                initial_seconds=0,
                min_seconds=0,
                max_seconds=120,
                on_change=lambda secs: print("Reheat time changed:", secs),
            )

            if self.controller.shared_data.get("show_reheat_time_attention", False):
                if hasattr(self.controller.view, "show_reheat_time_attention"):
                    self.controller.view.show_reheat_time_attention()
            else:
                if hasattr(self.controller.view, "hide_reheat_time_attention"):
                    self.controller.view.hide_reheat_time_attention()

        else:
            self.controller.view.hide_reheat_time_control()
            if hasattr(self.controller.view, "hide_reheat_time_attention"):
                self.controller.view.hide_reheat_time_attention()
            self.controller.shared_data["show_reheat_time_attention"] = False

    def on_hide(self):
        self.controller.view.set_overlay_image(None, None, None)
        self.controller.view.hide_reheat_time_control()

        if hasattr(self.controller.view, "hide_reheat_time_attention"):
            self.controller.view.hide_reheat_time_attention()
